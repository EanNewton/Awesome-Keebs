# Soldering switches

Unplug USB cable and solder mx switches.   
You can choose grid or mit layout.
If finish soldering, you should test typing.

# Install bottom PCB and acrylic cover

![hole](../img/assembly/plaid_pcb_top_screw.jpg)

## A
use screws, nuts, spacers and acrylic cover.
![screwA](../img/assembly/screw_a.jpg)

## B
use screws and nuts.
![screwB](../img/assembly/screw_b.jpg)

## Install keycaps

## COMPLETE!
![plaid](../img/plaid.jpg)