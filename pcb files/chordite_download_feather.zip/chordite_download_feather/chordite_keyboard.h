#include <Arduino.h>
#define MK_TOGGLE	0            // To the host, Mouse/kb toggling = no key.
#define BU_TOGGLE 0            // Ditto BLE/USB toggling.

// Boot subclass keyboards are supposed to be able to generate the
// following 115 USB decimal keycodes. 
#define	HID_NO_KEY            0
#define	HID_ERROR_ROLLOVER    1
#define	HID_POST_FAIL         2
#define	HID_ERROR_UNDEFINED   3
#define	HID_A                 4
#define	HID_B                 5
#define	HID_C                 6
#define	HID_D                 7
#define	HID_E                 8
#define	HID_F                 9
#define	HID_G                10
#define	HID_H                11
#define	HID_I                12
#define	HID_J                13
#define	HID_K                14
#define	HID_L                15
#define	HID_M                16
#define	HID_N                17
#define	HID_O                18
#define	HID_P                19
#define	HID_Q                20
#define	HID_R                21
#define	HID_S                22
#define	HID_T                23
#define	HID_U                24
#define	HID_V                25
#define	HID_W                26
#define	HID_X                27
#define	HID_Y                28
#define	HID_Z                29
#define	HID_1                30
#define	HID_2                31
#define	HID_3                32
#define	HID_4                33
#define	HID_5                34
#define	HID_6                35
#define	HID_7                36
#define	HID_8                37
#define	HID_9                38
#define	HID_0                39
#define	HID_ENTER            40
#define	HID_ESCAPE           41
#define	HID_BACKSPACE        42
#define	HID_TAB              43
#define	HID_SPACE            44
#define	HID_DASH             45
#define	HID_EQUALS           46
#define	HID_LEFT_BRACKET     47
#define	HID_RIGHT_BRACKET    48
#define	HID_BACKSLASH        49
#define	HID_NONUS_POUND      50
#define	HID_SEMICOLON        51
#define	HID_APOSTROPHE       52
#define	HID_ACCENT_GRAVE     53
#define	HID_COMMA            54
#define	HID_PERIOD           55
#define	HID_SLASH            56
#define	HID_CAPSLOCK	    	 57
#define	HID_F1               58
#define	HID_F2               59
#define	HID_F3               60
#define	HID_F4               61
#define	HID_F5               62
#define	HID_F6               63
#define	HID_F7               64
#define	HID_F8               65
#define	HID_F9               66
#define	HID_F10              67
#define	HID_F11              68
#define	HID_F12              69
#define	HID_PRINTSCREEN      70
#define	HID_SCROLLLOCK       71
#define	HID_PAUSE            72
#define	HID_INSERT           73
#define	HID_HOME             74
#define	HID_PAGEUP           75
#define	HID_DELETE           76
#define	HID_END			         77
#define	HID_PAGEDOWN         78
#define	HID_RIGHT_ARROW      79
#define	HID_LEFT_ARROW       80
#define	HID_DOWN_ARROW	     81
#define	HID_UP_ARROW	       82
#define	HID_KEYPAD_NUMLOCK   83
#define	HID_KEYPAD_DIVIDE    84
#define	HID_KEYPAD_TIMES	   85
#define	HID_KEYPAD_MINUS	   86
#define	HID_KEYPAD_PLUS	     87
#define	HID_KEYPAD_ENTER  	 88
#define	HID_KEYPAD_1         89
#define	HID_KEYPAD_2         90
#define	HID_KEYPAD_3         91
#define	HID_KEYPAD_4         92
#define	HID_KEYPAD_5         93
#define	HID_KEYPAD_6         94
#define	HID_KEYPAD_7         95
#define	HID_KEYPAD_8         96
#define	HID_KEYPAD_9         97
#define	HID_KEYPAD_0         98
#define	HID_KEYPAD_DELETE	   99
#define	HID_NONUS_BACKSLASH	100
#define	HID_APPLICATION     101
#define	HID_MAC_POWER	      102
#define	HID_KEYPAD_EQUALS   103
#define	HID_F13             104
#define	HID_F14             105
#define	HID_F15             106
#define	HID_LEFT_CONTROL    224
#define	HID_LEFT_SHIFT      225
#define	HID_LEFT_ALT        226
#define	HID_LEFT_GUI        227
#define	HID_RIGHT_CONTROL   228
#define	HID_RIGHT_SHIFT     229
#define	HID_RIGHT_ALT       230
#define	HID_RIGHT_GUI       231
#define BLE_USB_TOGGLE      232                     // Not official HID :-)

/* The array hid_keys implements the chord assignments I've used 
for several years. Edit to change. The array is now 5 "pages," each 4x4=16,
+8 = 88 bytes long. The ring finger selects the page, the middle finger 
the row and the index finger the column. The little finger moves you on to
the next chapter I guess :-)  I don't know how to use sizeof in program
memory. When you add or eliminate chords be sure to manually adjust 
SIZEOF_HID_KEYS !
*/
const unsigned char SIZEOF_HID_KEYS =88;        // Make sure this is right!
const unsigned char PROGMEM hid_keys[] = {
                                                       // Chapter 0, Page 0
      0, HID_SPACE, HID_BACKSPACE, HID_LEFT_SHIFT,               
  HID_E,     HID_I,         HID_N,          HID_C, 
  HID_T,     HID_O,         HID_S,          HID_F, 
  HID_R,     HID_M,         HID_W,          HID_Q,
  
                                                       // Chapter 0, Page 1
  HID_A,     HID_H,         HID_D,          HID_Y,                
  HID_L,     HID_P,         HID_B,          HID_J, 
  HID_U,     HID_G,         HID_V,          HID_X, 
  HID_K,     HID_Z,     MK_TOGGLE,        HID_TAB, 
  
                                                       // Chapter 0, Page 2
         HID_COMMA,        HID_PERIOD, HID_SEMICOLON, HID_APOSTROPHE, 
  HID_LEFT_BRACKET, HID_RIGHT_BRACKET, HID_BACKSLASH,      HID_SLASH,
             HID_1,             HID_2,         HID_3,          HID_4, 
             HID_5,             HID_6,         HID_7,          HID_8,

                                                       // Chapter 0, Page 3
           HID_9,            HID_0,      HID_DASH,       HID_EQUALS, 
       HID_ENTER, HID_ACCENT_GRAVE, HID_RIGHT_ALT, HID_LEFT_CONTROL, 
  HID_LEFT_ARROW,  HID_RIGHT_ARROW,  HID_UP_ARROW,   HID_DOWN_ARROW, 
      HID_PAGEUP,     HID_PAGEDOWN,    HID_INSERT,       HID_DELETE, 
      
                                                       // Chapter 1, Page 0
         HID_HOME,      HID_END,HID_PRINTSCREEN,     HID_PAUSE, 
  HID_RIGHT_SHIFT, HID_CAPSLOCK,   HID_LEFT_GUI, HID_RIGHT_GUI, 
           HID_F1,       HID_F2,         HID_F3,        HID_F4, 
           HID_F5,       HID_F6,         HID_F7,        HID_F8, 
           
                                                       // Chapter 1, Page 1
  HID_F9,        HID_F10,        HID_F11, HID_F12, 
  HID_ESCAPE, HID_ESCAPE,      BU_TOGGLE, HID_F15    
  };
