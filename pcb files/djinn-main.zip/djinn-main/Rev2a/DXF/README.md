# DXF Files

**! WARNING !**

**! WARNING !**

**! WARNING !**

These files are untested. They may be x1000 too large or x1000 too small.

Use at your own risk.

3D-print these if you have a printer available, before investing in carbon fibre plates or brass bases. Check geometry and sizing before spending cash.