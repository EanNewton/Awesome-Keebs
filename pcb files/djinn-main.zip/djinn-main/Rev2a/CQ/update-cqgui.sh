#!/bin/sh
conda create -n cqgui -c cadquery -c conda-forge cq-editor=master cairosvg